
function paycheck()
{
 var a = parseFloat($("#InputPay").val());
 var b = parseFloat($("#InputHour").val());
 var c = parseFloat($("#InputDeductions").val());

//var a = document.forms["pays"]["PayRate"].value;
 //var b = document.forms["pays"]["Hours"].value;
 //var c = document.forms["pays"]["OtherDeductions"].value;

 var pay1 = ((a*b)-c);
 
parseFloat(document.getElementById("pay1").innerHTML = pay1);  

// alert("Your pay is" + pay1);
}
